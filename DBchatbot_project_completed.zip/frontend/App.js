// React frontend entry point
import React from 'react';
const App = () => <div>Chatbot Interface</div>;
export default App;
-- Sample data for the database
INSERT INTO Suppliers VALUES (1, 'Supplier A', 'contact@suppliera.com', 'Electronics');
INSERT INTO Products VALUES (1, 'Laptop', 'Brand X', 999.99, 'Electronics', 'High-performance laptop', 1);
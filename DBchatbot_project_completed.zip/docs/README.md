# AI-Powered Chatbot for Supplier and Product Information

This project implements a chatbot system to query a supplier and product database.
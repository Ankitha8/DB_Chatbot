-- SQL schema for products and suppliers
CREATE TABLE Products (
    ID INT PRIMARY KEY,
    Name VARCHAR(255),
    Brand VARCHAR(255),
    Price DECIMAL(10, 2),
    Category VARCHAR(255),
    Description TEXT,
    SupplierID INT
);

CREATE TABLE Suppliers (
    ID INT PRIMARY KEY,
    Name VARCHAR(255),
    ContactInfo VARCHAR(255),
    ProductCategories VARCHAR(255)
);